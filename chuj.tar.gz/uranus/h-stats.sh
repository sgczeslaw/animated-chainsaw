#!/usr/bin/env bash

# TODO: HTTP API

. /hive/miners/custom/uranus/h-manifest.conf
temp=$(/hive/sbin/cpu-temp)
line=$(tail -n1 ${CUSTOM_LOG_BASENAME}.log)
hs=$(echo $line | grep -o "^[0-9]*")
hs_units="hs"

khs=$(echo $hs | awk '{print $1/1000}')
stats=$(jq -nc --argjson hs "$hs" --arg hs_units "$hs_units" --argjson temp "$temp" '{hs: [$hs] , $hs_units, temp:[$temp]}')