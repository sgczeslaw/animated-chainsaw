#!/usr/bin/env bash

if [[ $CUSTOM_URL == wss* ]];
then
    username=`echo $CUSTOM_TEMPLATE | cut -d . -f 1`
else
    username=$CUSTOM_TEMPLATE
fi
echo -e "-o $CUSTOM_URL -u $username $CUSTOM_USER_CONFIG" > $CUSTOM_CONFIG_FILENAME