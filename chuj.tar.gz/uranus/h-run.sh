#!/usr/bin/env bash

. h-manifest.conf
./uranus $(< $CUSTOM_CONFIG_FILENAME) 2>&1 | tee --append $CUSTOM_LOG_BASENAME.log